package com.bjpowernode.springbot.service;

import com.bjpowernode.springbot.model.User;

public interface UserService {
    User queryStudentById(Integer id);
}
