package com.bjpowernode.springbot.web;

import com.bjpowernode.springbot.model.User;
import com.bjpowernode.springbot.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

public class MyController {
    @Controller
    public class IndexController {
        @Autowired
        private UserService userService;

        @RequestMapping(value = "/user")
        public @ResponseBody Object User(Integer id){
            User user=userService.queryStudentById(id);
            return user;

        }


    }

}
