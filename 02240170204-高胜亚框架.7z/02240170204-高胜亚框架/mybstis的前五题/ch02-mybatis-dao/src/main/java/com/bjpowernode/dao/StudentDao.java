package com.bjpowernode.dao;

import com.bjpowernode.domain.Student;

import java.util.List;

public interface StudentDao {

    List<Student> selectStudents();

    List<Student> selectStudents1();

    List<Student> selectStudents2();

    List<Student> selectStudents3();

    List<Student> selectStudents4();
    List<Student> selectStudents5();
}
