package com.bjpowernode;


import com.bjpowernode.dao.StudentDao;
import com.bjpowernode.dao.impl.StudentDaoImpl;
import com.bjpowernode.domain.Student;
import org.junit.Test;


import java.util.List;

public class TestMyBatis {
//   第 1 题  利用MyBatis框架技术查询数据库中部门10中所有经理(MANAGER)和部门20中所有办事员(CLERK)的详细资料。（6分）
    @Test
    public void testSelectStudents(){
        StudentDao dao  = (StudentDao) new StudentDaoImpl();
        List<Student> studentList  = dao.selectStudents();
        for(Student stu:studentList){
            System.out.println(stu);
        }
    }
//第 2 题  利用MyBatis框架技术查询数据库中不收取佣金或收取的佣金低于100的员工的详细信息。（6分）
    @Test
    public void testSelectStudents1(){
        StudentDao dao  = (StudentDao) new StudentDaoImpl();
        List<Student> studentList  = dao.selectStudents1();
        for(Student stu:studentList){
            System.out.println(stu);
        }
    }

//    第 3 题  利用MyBatis框架技术查询数据库中找出佣金高于薪金的员工。（6分）
            @Test
            public void testSelectStudents2(){
                StudentDao dao  = (StudentDao) new StudentDaoImpl();
                List<Student> studentList  = dao.selectStudents2();
                for(Student stu:studentList){
                    System.out.println(stu);
                }
            }

//第 4 题  利用MyBatis框架技术查询数据库中找出佣金高于薪金的60%的员工。（6分）
            @Test
            public void testSelectStudents3(){
                StudentDao dao  = (StudentDao) new StudentDaoImpl();
                List<Student> studentList  = dao.selectStudents3();
                for(Student stu:studentList){
                    System.out.println(stu);
                }
            }
//第 5 题  利用MyBatis框架技术查询数据库中在部门"SALES"(销售部)工作的员工姓名，假定不知道销售部的部门编号。（6分）
                @Test
                public void testSelectStudents4(){
                    StudentDao dao  = (StudentDao) new StudentDaoImpl();
                    List<Student> studentList  = dao.selectStudents4();
                    for(Student stu:studentList){
                        System.out.println(stu);
                    }
                }
//第 7 题（选做题）  利用MyBatis框架技术查询数据库20-40号部门中,姓是A,F,G开头的员工信息,按工资降序排列。（6分）
                @Test
                public void testSelectStudents5(){
                    StudentDao dao  = (StudentDao) new StudentDaoImpl();
                    List<Student> studentList  = dao.selectStudents5();
                    for(Student stu:studentList){
                        System.out.println(stu);
                    }
}

}
